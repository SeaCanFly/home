#include"client.h"

int main()
{
	if (connectToIOCP((char*)"127.0.0.1",9999) == false)
	{
		printf("connect failed\n");
	}
	if (startIOThread() == false)
	{
		printf("start thread failed\n");
	}
	loginCmd();
	while (1)
	{
		int sum = 0;
		for (int i = 0; i < thread_count; i++)
		{
			sum += thread_exit_count[i];
		}
		if (sum == thread_count)
			break;
		else Sleep(1000);
	}
	close();
	return 0;
}