#pragma once
#define _WINSOCK_DEPRECATED_NO_WARNINGS
#define _CRT_SECURE_NO_WARNINGS
#define print(format,...) //printf(format,__VA_ARGS__)
#include <SDKDDKVer.h>
#include <stdio.h>
#include <process.h>
#include <limits.h>
#include <WinSock2.h>
#include <time.h>
#include <direct.h>
#include <io.h>
#pragma comment(lib,"ws2_32")
#define BUFSIZE sizeof(Pack)
#define DATASIZE 4096
int thread_count = 0;
HANDLE completion_port = 0;
SOCKET listen_socket = 0;
int quit = 0;
int chat_model = 0;
int move_model = 0;
int thread_exit_count[64] = { 0 };
int c;
char current_user_name[20] = { '\0' };
FILE* user_log=0;
time_t now;
enum IOType
{
	IO_SEND,
	IO_RECV,
};
#pragma pack(1)
struct Pack
{
	char data[DATASIZE] = { 0 };
};
#pragma pack()
struct OverlappedSock
{
	OVERLAPPED		overlapped;
	IOType			io_type;
	WSABUF			wsa_buffer;
	char			buffer[BUFSIZE];
};
bool mysend(const char* buf, int len);
bool loginCmd();
unsigned int __stdcall chatCmd(void* p);
bool startIOThread();
bool myrecv();
bool mysend(const char* buf, int len);
unsigned int __stdcall workerThread(LPVOID lpParam);
bool connectToIOCP(char* ip,int server_port)
{
	SYSTEM_INFO sysinfo;
	SecureZeroMemory(&sysinfo, sizeof(sysinfo));
	GetSystemInfo(&sysinfo);
	thread_count = sysinfo.dwNumberOfProcessors * 2;
	print("thread count:%d\n", thread_count);
	WSADATA wsa;
	if (WSAStartup(MAKEWORD(2, 2), &wsa) != 0)
		return false;
	completion_port = CreateIoCompletionPort(INVALID_HANDLE_VALUE, NULL, 0, 0);
	print("Completion Port:%p\n", completion_port);

	if (completion_port == 0)
	{
		printf("Completion Port Create Fail!\n");
		return false;
	}
	listen_socket = WSASocket(AF_INET, SOCK_STREAM, IPPROTO_TCP, NULL, 0, WSA_FLAG_OVERLAPPED);
	CreateIoCompletionPort((HANDLE)listen_socket, completion_port, 0, 0);
	if (listen_socket == 0)
	{
		printf("Socket Create Fail!\n");
		return false;
	}
	SOCKADDR_IN serveraddr;
	SecureZeroMemory(&serveraddr, sizeof(serveraddr));
	serveraddr.sin_family = AF_INET;
	serveraddr.sin_addr.s_addr = inet_addr(ip);
	serveraddr.sin_port = htons(server_port);
	int opt = 1;
	setsockopt(listen_socket, SOL_SOCKET, SO_REUSEADDR, (const char*)&opt, sizeof(int));
	if (connect(listen_socket, (sockaddr*)&serveraddr, sizeof(serveraddr)) == SOCKET_ERROR)
	{
		printf("connect error\n");
	}
	return myrecv();
}
bool loginCmd()
{
	char sub_select[DATASIZE] = { 0 };
	char send_buffer[DATASIZE] = { 0 };
	char temp[DATASIZE - 2] = { 0 };
	printf("-------Input '/q' to exit\n-------Input 0 to sign up\n-------Input 1 to login\n");
	while (1)
	{
		printf("\r[select:]");
		scanf(" %[^\n]s", sub_select);	
		if (strcmp(sub_select, "/q") == 0)
		{
			memset(send_buffer, 0, DATASIZE);
			strcpy(send_buffer, "/q");
			//sprintf(send_buffer, "/q", 3);
			mysend(send_buffer, DATASIZE);
			return true;
		}
		else if (strcmp(sub_select, "0") == 0)
		{
			char name[20] = { 0 };
			char pw[20] = { 0 };
			printf("[sign up:]");
			
			scanf(" %[^\n]s", temp);
			sscanf(temp, " %s %s", name, pw);
			memset(send_buffer, 0, DATASIZE);
			sprintf(send_buffer, "/a%s %s", name, pw);
			mysend(send_buffer, DATASIZE);
			return true;
		}
		else if (strcmp(sub_select, "1") == 0)
		{
			memset(send_buffer, 0, DATASIZE);
			printf("[login:]");		
			scanf(" %[^\n]s", temp);
			sscanf(temp, "%s", current_user_name);
			sprintf(send_buffer, "/l%s", temp);
			mysend(send_buffer, DATASIZE);
			return true;
		}
		continue;
	}
	return true;
}
unsigned int __stdcall selectCmd(void* p)
{
	char sub_select[DATASIZE] = { 0 };
	char send_buffer[DATASIZE] = { 0 };
	char temp[DATASIZE - 2] = { 0 };
	memset(send_buffer, 0, DATASIZE);
	while (1)
	{
		printf("-------Press \"/q\" to exit\n-------Press 1 to Move\n-------Press 2 to chat\n");
		printf("\r[select:]");		
		scanf(" %s", sub_select);
		if (strcmp(sub_select, "/q") == 0)
		{
			memset(send_buffer, 0, DATASIZE);
			//sprintf(send_buffer, "/q", 3);
			strcpy(send_buffer, "/q");
			mysend(send_buffer, DATASIZE);
			return 0;
		}
		else if (strcmp(sub_select, "1") == 0)
		{
			move_model = 1;
			printf("---------Press \"/out\" to exit move model---------\n");
			memset(send_buffer, 0, DATASIZE);
			//sprintf(send_buffer, "/p", 3);
			strcpy(send_buffer, "/p");
			mysend(send_buffer, DATASIZE);
			return 0;
		}
		else if (strcmp(sub_select, "2") == 0)
		{
			chat_model = 1;
			printf("---------Press \"/out\" to exit chat model---------\n");
			memset(send_buffer, 0, DATASIZE);
			sprintf(send_buffer, "/r");
			mysend(send_buffer, DATASIZE);
			return 0;
		}
		continue;
	}
}
unsigned int __stdcall moveCmd(void* p)
{
	while (move_model)
	{
		char send_buffer[DATASIZE] = { 0 };
		char temp[DATASIZE - 2] = { 0 };
		printf("[input x y z:]");
		scanf(" %[^\n]s", temp);
		if (strcmp(temp, "/out") == 0)
		{
			move_model = 0;
			memset(send_buffer, 0, DATASIZE);
			sprintf(send_buffer, "/o");
			mysend(send_buffer, DATASIZE);
			return 0;
		}
		memset(send_buffer, 0, DATASIZE);
		sprintf(send_buffer, "/m%s", temp);
		mysend(send_buffer, DATASIZE);
	}
	return 1;
}
unsigned int __stdcall chatCmd(void* p)
{
	while (chat_model)
	{
		char send_buffer[DATASIZE] = { 0 };
		char temp[DATASIZE - 2] = { 0 };
		printf("[chat:]>");
		scanf(" %[^\n]s", temp);
		if (strcmp(temp, "/out") == 0)
		{
			chat_model = 0;			
			time(&now);
			char nt[257] = { '\0' };
			ctime_s(nt, sizeof(nt), &now);
			fputs(nt, user_log);
			if (user_log)fclose(user_log);
			user_log = 0;
			memset(send_buffer, 0, DATASIZE);
			sprintf(send_buffer, "/oc");
			mysend(send_buffer, DATASIZE);
			return 0;
		}
		memset(send_buffer, 0, DATASIZE);
		sprintf(send_buffer, "/t%s", temp);
		mysend(send_buffer, DATASIZE);
	}
	return 1;
}
bool startIOThread()
{
	for (int i = 0; i < thread_count; ++i)
	{
		unsigned long dwThreadId;
		HANDLE threadHandle = (HANDLE)_beginthreadex(NULL, 0, workerThread, (LPVOID)&thread_exit_count[i], 0, (unsigned int*)&dwThreadId);
		if (threadHandle == INVALID_HANDLE_VALUE)
		{
			printf("Create Thread Fail!\n");
			return false;
		}
		print("%d Thread id:%d Created\n", i,dwThreadId);
		CloseHandle(threadHandle);
	}
	return true;
}

bool receiveCompletion(OverlappedSock* ovsock, unsigned long dwTransferred)
{	
	char* temp = ovsock->buffer;
	if (*temp == '\0')
	{
		++temp;
		printf("\r%s[select:]", temp);
		goto recvend;
	}
	if (*temp != '/')
	{
		goto recvend;
	}
	++temp;
	if (*temp=='q')
	{
		free(ovsock);
		ovsock = 0;
		quit = 1;
		CloseHandle(completion_port);
		return true;
	}
	else if (*temp == 'l')
	{
		++temp;
		if (*temp == '1')
		{
			printf("\rlogin successed\n");
		}
		else
		{
			printf("\rlogin failed\n");
			memset(current_user_name, '\0', sizeof(current_user_name));
			loginCmd();
		}
	}
	else if (*temp == 's')
	{
		HANDLE ts = (HANDLE)_beginthreadex(0, 0, selectCmd, 0, 0, 0);
		CloseHandle(ts);
	}
	else if (*temp == 'c')
	{
		if (chat_model)
		{			
			time(&now);
			char nt[257] = { '\0' };
			ctime_s(nt, sizeof(nt), &now);
			char path[256] = { 0 };
			if (_access("chat", 0) )
			{
				_mkdir("chat");
			}
			sprintf(path, "chat/%s.dat", current_user_name);
			if (!user_log)user_log = fopen(path, "a");
			if (!user_log)
			{
				printf("chat file open failed\n");
				
			}
			fputs(nt, user_log);
			HANDLE tc = (HANDLE)_beginthreadex(0, 0, chatCmd, 0, 0, 0);
			CloseHandle(tc);

		}
	}
	else if (*temp == 'm')
	{
		if (move_model)
		{
			HANDLE tm = (HANDLE)_beginthreadex(0, 0, moveCmd, 0, 0, 0);
			CloseHandle(tm);
		}
	}
	else if (*temp == 't')
	{
		++temp;

		if (chat_model)
		{
			printf("\r\t%s\n[chat:]", temp);
			char store_str[DATASIZE - 2] = { 0 };	
			sprintf(store_str, "%s\n", temp);
			fputs(store_str, user_log);
		}
		else if (move_model)
		{
			printf("\r%s\n[input x y z:]", temp);
		}
		else
		{
			printf("\r%s\n[select:]", temp);
		}
	}
	else if (*temp == 'a')
	{
		++temp;
		if (*temp == '1')
		{
			printf("\rsign up successed\n");
		}
		else
		{
			printf("\rsign up failed\n");
		}
		loginCmd();
	}

recvend:
	free(ovsock);
	ovsock = 0;
	return myrecv();
}
bool myrecv()
{

	OverlappedSock* recvOV = (OverlappedSock*)calloc(1, sizeof(OverlappedSock));
	recvOV->io_type = IO_RECV;
	unsigned long flags = 0;
	unsigned long recvbytes = 0;
	recvOV->wsa_buffer.buf = recvOV->buffer;
	recvOV->wsa_buffer.len = BUFSIZE;

	if (WSARecv(listen_socket, &recvOV->wsa_buffer, 1, &recvbytes, &flags, (LPWSAOVERLAPPED)recvOV, NULL) == SOCKET_ERROR)
	{
		if (WSAGetLastError() != WSA_IO_PENDING)
		{
			printf("recv error..\n");
			return false;
		}
	}
	print("Waiting Message...\n");
	return true;
}
bool sendCompletion(OverlappedSock* ovsock, unsigned long dwTransferred)
{
	print("Message sent\n");
	if (ovsock->wsa_buffer.len != dwTransferred)
	{
		free(ovsock);
		ovsock = 0;
		return false;
	}
	free(ovsock);
	ovsock = 0;
	return true;
}
bool mysend(const char* buf, int len)
{
	OverlappedSock* sendOV = (OverlappedSock*)calloc(1, sizeof(OverlappedSock));
	sendOV->io_type = IO_SEND;
	memcpy_s(sendOV->buffer, BUFSIZE, buf, len);
	unsigned long sendbytes = 0;
	unsigned long flags = 0;
	sendOV->wsa_buffer.buf = sendOV->buffer;
	sendOV->wsa_buffer.len = len;
	if (WSASend(listen_socket, &sendOV->wsa_buffer, 1, &sendbytes, flags, (LPWSAOVERLAPPED)&sendOV->overlapped, NULL) == SOCKET_ERROR)
	{
		if (WSAGetLastError() != WSA_IO_PENDING)
		{
			printf("send error...\n");
			return false;
		}
	}
	print("Sending message...\n");
	return true;
}
void close()
{
	if(user_log)fclose(user_log);
	closesocket(listen_socket);
	WSACleanup();
	printf("Client closed\n");
}
unsigned int __stdcall workerThread(LPVOID lpParam)
{
	int* i = (int*)lpParam;
	print("thread %d[Completion Port:%p] started\n", GetCurrentThreadId(), completion_port);
	while (!quit)
	{
		unsigned long dwTransferred;
		OverlappedSock* OvSock = nullptr;
		int tid = GetCurrentThreadId();
		int ret = GetQueuedCompletionStatus(completion_port, &dwTransferred, (PULONG_PTR)&tid, (LPOVERLAPPED*)&OvSock, -1);
		if (ret == 0 && GetLastError() == WAIT_TIMEOUT)
		{
			printf("Thread Time Out\n");
			continue;
		}
		if (ret == 0 || dwTransferred == 0)
		{
			printf("Recive Data is zero...\n");
			continue;
		}
		if (OvSock == nullptr)
		{
			printf("Recive Data is zero...Overlapped error\n");
			break;
		}
		bool completOK = true;
		switch (OvSock->io_type)
		{
			case IO_SEND:
				completOK = sendCompletion(OvSock, dwTransferred);
				break;
			case IO_RECV:
				completOK = receiveCompletion(OvSock, dwTransferred);
				break;
			default:
				printf("IO type Fail : %d\n", OvSock->io_type);
				break;
		}
		if (!completOK)
		{
			printf("Completion Error...\n");
			break;
		}
	}
	*i = 1;
	return 0;
}