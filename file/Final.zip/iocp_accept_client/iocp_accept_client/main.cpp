#include"client.h"

int main()
{	
	char ip[128] = { '\0' };
	printf("-------1 to local\n-------other to remote\n");
	char ip_select[128] = { '\0' };
	printf("[:]>");
	scanf("%s", ip_select);
	if (strcmp(ip_select, "1") == 0)
	{
		strcpy(ip, "127.0.0.1");

	}
	else
	{
		strcpy(ip, "35.234.50.219");

	}
	
	if (connectToIOCP(ip,9999) == false)
	{
		printf("connect failed\n");
	}
	if (startIOThread() == false)
	{
		printf("start thread failed\n");
	}
	loginCmd();
	while (1)
	{
		int sum = 0;
		for (int i = 0; i < thread_count; i++)
		{
			sum += thread_exit_count[i];
		}
		if (sum == thread_count)
			break;
		else Sleep(1000);
	}
	close();
	return 0;
}